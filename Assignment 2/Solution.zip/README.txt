Name: ADAM TRALKA
Student ID: n10133542

Name: HARRY NEWTON
Student ID: n10133810

Please indicate for each question/task whether it is attempted/works/not attempted. 
If you have attempted it but it doesn't run successfully select 'attempted', if it runs then select 'works', otherwise select 'not attempted.
For Task 5 select either attempted/not attempted.

--------
Task 1
--------
Create database: works
Create tables: works

--------
Task 2
--------
Q1. Works
Q2. Works
Q3. Works
Q4. Works
Q5. Attempted
Q6. Attempted

--------
Task 3
--------
Insert: should work
Delete: should work
Update: should work

--------
Task 4
--------
Create Index: works
Create View: attempted

--------
Task 5
--------
Attempted

